﻿namespace NCalc
{
    public delegate void EvaluateParameterHandler(string name, ParameterArgs args);
}
